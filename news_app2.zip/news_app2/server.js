var express = require('express');
var bodyParser = require('body-parser');  //
var app = express();

var router = express.Router();
var appRoutes = require('./app/routes/api')(router);
app.use('/api', appRoutes); 

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/news1');
var newsr= mongoose.model('news', mongoose.Schema({
	title:String,
	venue:String,
	description:String,
	date:String,
	time:String,
	district:String,
	status:String,
	correspondantId:String

}));


app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/client'));

/*app.get('/api/news1', function(req, res){
	newsr.find(function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
}); */

app.get('/api/news1/pending', function(req, res){
	newsr.find().
	where('status').equals('Pending').
  	exec(
  	function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
	
});

app.get('/api/news1/received', function(req, res){
	newsr.find().
	where('status').equals('Completed').
  	exec(
  	function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
	
});

app.get('/api/news1/na', function(req, res){
	newsr.find().
	where('status').equals('Not assigned').
  	exec(
  	function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
	
});


app.get('/api/news1/:id', function(req, res){
	newsr.findOne({_id:req.params.id}, function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
}); 
app.post('/api/news1', function(req, res){
	newsr.create( req.body, function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
});

app.delete('/api/news1/:id', function(req, res){
	newsr.findOneAndRemove({_id:req.params.id}, function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
});+
app.put('/api/news1/:id', function(req, res){
	var query = {
		title:req.body.title,
		venue:req.body.venue,
		description:req.body.description,
		date:req.body.date,
		time:req.body.time,
		district:req.body.district,
		status:req.body.status,
		correspondantId:req.body.correspondantId
	};
	newsr.findOneAndUpdate({_id:req.params.id}, query, function(err, news){
		if(err)
			res.send(err);
		res.json(news);
	});
});






app.listen(3000, function(){
	console.log('server is running on port 3000...');
})