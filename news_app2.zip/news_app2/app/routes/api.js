// User Login Route
//http://localhost:port/api/authenticate

module.exports = function(router){
	router.post('/authenticate', function(req,res){
			res.send('testing new route');
	});

	return router;

}