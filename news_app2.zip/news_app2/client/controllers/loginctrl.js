
angular.module('loginctrl',[])

myApp.controller('mainctrl', function(){
	/*console.log('testing main ctrl');*/
});
