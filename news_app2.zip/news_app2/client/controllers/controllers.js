angular.module('myapp',[])
myApp.controller('newsController', function($scope,$route,$routeParams,$http){
	$scope.getNews = function(){
		$http.get('/api/news1/na').then(function(response){
			$scope.news1 = response.data;
		});
	};

	$scope.getRecNews = function(){
		$http.get('/api/news1/received').then(function(response){
			$scope.news1 = response.data;
		});
	}; 

	$scope.getPenNews = function(){
		$http.get('/api/news1/pending').then(function(response){
			$scope.news1 = response.data;
		});
	};

	
	
	$scope.showNews = function(){
		var id = $routeParams.id;
		$http.get('/api/news1/'+ id).then(function(response){
			$scope.news = response.data;
		});
	};

	$scope.addNews = function(){
		
		$http.post('/api/news1/', $scope.news).then(function(response){
			//$scope.news = response.data;
			window.location.href = '/';
		});
	};

	$scope.updateNews = function(){
		var id = $routeParams.id;
		$http.put('/api/news1/'+ id , $scope.news).then(function(response){
			//$scope.news = response.data;
			window.location.href = '/';
		});
	};

	$scope.deleteNews = function(id){
		var id = id;
		$http.delete('/api/news1/'+ id).then(function(response){
			$route.reload();
		});
	};

	
});