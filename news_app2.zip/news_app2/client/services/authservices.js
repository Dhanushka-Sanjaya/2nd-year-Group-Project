angular.module('authServices',[])

.factory('Auth', function(regData){
	var authFactory = {};

	authFactory.login = function(regData){
		return $http.post();
	}
});