var myApp = angular.module('myApp',['ngRoute']);
myApp.config(function($routeProvider){
	$routeProvider
		.when('/', {
			templateUrl:'templates/list.html',
			controller:'newsController'
		})
		.when('/home', {
			templateUrl:'templates/list.html',
			controller:'newsController'
		})
		.when('/news1', {
			templateUrl:'templates/list.html',
			controller:'newsController'
		})
		.when('/news1/create', {
			templateUrl:'templates/add.html',
			controller:'newsController'
		})
		.when('/news1/:id/edit', {
			templateUrl:'templates/edit.html',
			controller:'newsController'
		})
		.when('/news1/:id/show', {
			templateUrl:'templates/show.html',
			controller:'newsController'
		})
		.when('/news1/:id/showRecNews', {
			templateUrl:'templates/showRecNews.html',
			controller:'newsController'

		})
		.when('/news1/:id/sp', {
			templateUrl:'templates/showPending.html',
			controller:'newsController'

		})



		.when('/menu1', {
			templateUrl:'templates/listRe.html',
			controller:'newsController'
		})
		.when('/menu2', {
			templateUrl:'templates/pendinNews.html',
			controller:'newsController'
		})


		.when('/login', {
			templateUrl:'templates/login.html',
			
			
		})

		
});


